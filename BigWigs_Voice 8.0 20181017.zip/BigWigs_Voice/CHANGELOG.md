# BigWigs +Voice

## [v8.0.1](https://github.com/BigWigsMods/BigWigs_Voice/tree/v8.0.1) (2018-08-13)
[Full Changelog](https://github.com/BigWigsMods/BigWigs_Voice/compare/v8.0.0...v8.0.1)

- Merge branch 'battle-for-azeroth'  
- Add sounds for dungeons  
- Prepare for Battle for Azeroth  
